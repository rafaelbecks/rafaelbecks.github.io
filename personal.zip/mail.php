<?php 
$nombre=$_REQUEST['name'];
$mailfrom=$_REQUEST['mail'];
$mensaje=$_REQUEST['message'];
$subject=$_REQUEST['subject'];
$msg = "Has recibido un mensaje de ".$nombre." (correo:".$mailfrom.") \n Mensaje: ".$mensaje;
$mensajeEnviar = wordwrap($msg,70);

if(@mail("rafaelbecks93@gmail.com",$subject,$mensajeEnviar)){
	echo "Tu mensaje fue enviado satisfactoriamente, me pondré en contacto cuanto antes";
}else
  {
  	echo "Ocurrió un error enviando tu mensaje";
  }
?>
